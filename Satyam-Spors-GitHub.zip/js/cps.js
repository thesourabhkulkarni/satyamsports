(function(){
  var track = document.getElementById('ssTrack');
  var prevBtn = document.querySelector('.ss-slider-section .ss-prev');
  var nextBtn = document.querySelector('.ss-slider-section .ss-next');
  var dotsWrap = document.getElementById('ssDots');
  var cards = track.querySelectorAll('.ss-card');

  // Build dots
  cards.forEach(function(_, i){
    var d = document.createElement('span');
    if(i === 0) d.classList.add('active');
    dotsWrap.appendChild(d);
  });
  var dots = dotsWrap.querySelectorAll('span');

  function cardStep(){
    var card = cards[0];
    var style = window.getComputedStyle(track);
    var gap = parseFloat(style.gap) || 16;
    return card.getBoundingClientRect().width + gap;
  }

  function updateNavState(){
    var maxScroll = track.scrollWidth - track.clientWidth - 2;
    if(prevBtn) prevBtn.disabled = track.scrollLeft <= 2;
    if(nextBtn) nextBtn.disabled = track.scrollLeft >= maxScroll;

    var idx = Math.round(track.scrollLeft / cardStep());
    dots.forEach(function(d, i){ d.classList.toggle('active', i === idx); });
  }

  if(prevBtn) prevBtn.addEventListener('click', function(){
    track.scrollBy({left: -cardStep()*2, behavior:'smooth'});
  });
  if(nextBtn) nextBtn.addEventListener('click', function(){
    track.scrollBy({left: cardStep()*2, behavior:'smooth'});
  });

  var scrollTimer;
  track.addEventListener('scroll', function(){
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(updateNavState, 60);
  }, {passive:true});

  window.addEventListener('resize', updateNavState);
  updateNavState();

  // ---- Mouse drag-to-scroll (desktop) ----
  var isDown = false;
  var startX = 0;
  var scrollStart = 0;
  var moved = false;

  track.addEventListener('mousedown', function(e){
    isDown = true;
    moved = false;
    track.classList.add('ss-dragging');
    startX = e.pageX;
    scrollStart = track.scrollLeft;
  });

  window.addEventListener('mousemove', function(e){
    if(!isDown) return;
    var dx = e.pageX - startX;
    if(Math.abs(dx) > 4) moved = true;
    track.scrollLeft = scrollStart - dx;
  });

  function endDrag(){
    if(!isDown) return;
    isDown = false;
    track.classList.remove('ss-dragging');
    updateNavState();
  }
  window.addEventListener('mouseup', endDrag);
  track.addEventListener('mouseleave', endDrag);

  // Prevent a dragged mouse-up from firing the WhatsApp link click
  track.addEventListener('click', function(e){
    if(moved){
      e.preventDefault();
      e.stopPropagation();
      moved = false;
    }
  }, true);
})();