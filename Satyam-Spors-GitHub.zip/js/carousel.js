(function(){
  const track = document.getElementById('track');
  const wrapper = document.getElementById('carousel');
  const dotsContainer = document.getElementById('dots');
  const progressBar = document.getElementById('progressBar');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');

  const realSlides = Array.from(track.children);
  const slideCount = realSlides.length;
  const DELAY = 10000;

  const firstClone = realSlides[0].cloneNode(true);
  const lastClone = realSlides[slideCount - 1].cloneNode(true);
  track.appendChild(firstClone);
  track.insertBefore(lastClone, realSlides[0]);

  let index = 1;
  const total = slideCount + 2;

  function setTrackPosition(withTransition){
    track.classList.toggle('no-transition', !withTransition);
    track.style.transform = 'translateX(' + (-index * 100) + '%)';
  }

  for (let i = 0; i < slideCount; i++){
    const dot = document.createElement('div');
    dot.className = 'dot' + (i === 0 ? ' active' : '');
    dot.addEventListener('click', () => goToRealSlide(i));
    dotsContainer.appendChild(dot);
  }
  const dots = Array.from(dotsContainer.children);

  function updateDots(){
    let real = index - 1;
    if (real < 0) real = slideCount - 1;
    if (real >= slideCount) real = 0;
    dots.forEach((d, i) => d.classList.toggle('active', i === real));
  }

  function goToRealSlide(i){
    index = i + 1;
    setTrackPosition(true);
    updateDots();
    restartAutoplay();
  }

  setTrackPosition(false);

  function next(){
    index++;
    setTrackPosition(true);
    updateDots();
  }

  function prev(){
    index--;
    setTrackPosition(true);
    updateDots();
  }

  track.addEventListener('transitionend', () => {
    if (index === total - 1){
      index = 1;
      setTrackPosition(false);
    } else if (index === 0){
      index = slideCount;
      setTrackPosition(false);
    }
  });

  let autoplayTimer = null;
  let progressStart = null;
  let progressRAF = null;

  function animateProgress(timestamp){
    if (!progressStart) progressStart = timestamp;
    const elapsed = timestamp - progressStart;
    const pct = Math.min((elapsed / DELAY) * 100, 100);
    progressBar.style.width = pct + '%';
    if (pct < 100){
      progressRAF = requestAnimationFrame(animateProgress);
    }
  }

  function startAutoplay(){
    progressStart = null;
    progressBar.style.width = '0%';
    progressRAF = requestAnimationFrame(animateProgress);
    autoplayTimer = setInterval(() => {
      next();
      progressStart = null;
      progressBar.style.width = '0%';
    }, DELAY);
  }

  function stopAutoplay(){
    clearInterval(autoplayTimer);
    cancelAnimationFrame(progressRAF);
  }

  function restartAutoplay(){
    stopAutoplay();
    startAutoplay();
  }

  nextBtn.addEventListener('click', () => { next(); restartAutoplay(); });
  prevBtn.addEventListener('click', () => { prev(); restartAutoplay(); });

  wrapper.addEventListener('mouseenter', stopAutoplay);
  wrapper.addEventListener('mouseleave', startAutoplay);

  let startX = 0;
  let isDragging = false;

  function getTranslateXPercent(){
    return -index * 100;
  }

  wrapper.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    isDragging = true;
    stopAutoplay();
    track.classList.add('no-transition');
  }, {passive:true});

  wrapper.addEventListener('touchmove', (e) => {
    if (!isDragging) return;
    const currentX = e.touches[0].clientX;
    const diff = currentX - startX;
    const wrapperWidth = wrapper.getBoundingClientRect().width;
    const diffPercent = (diff / wrapperWidth) * 100;
    track.style.transform = 'translateX(' + (getTranslateXPercent() + diffPercent) + '%)';
  }, {passive:true});

  wrapper.addEventListener('touchend', (e) => {
    if (!isDragging) return;
    isDragging = false;
    const endX = e.changedTouches[0].clientX;
    const diff = endX - startX;
    track.classList.remove('no-transition');
    if (diff > 50){
      prev();
    } else if (diff < -50){
      next();
    } else {
      setTrackPosition(true);
    }
    updateDots();
    restartAutoplay();
  });

  wrapper.setAttribute('tabindex', '0');
  wrapper.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft'){ prev(); restartAutoplay(); }
    if (e.key === 'ArrowRight'){ next(); restartAutoplay(); }
  });

  startAutoplay();
})();