(function(){
  document.querySelectorAll('.ss-fc').forEach(function(root){
    var track=root.querySelector('.ss-track'),prev=root.querySelector('[data-prev]'),next=root.querySelector('[data-next]'),bar=root.querySelector('.ss-bar i');
    var cards=track.children,down=false,drag=false,sx=0,sl=0,dx=0,moved=false,raf=0;
    function step(){return cards.length>1?cards[1].offsetLeft-cards[0].offsetLeft:track.clientWidth}
    function update(){
      raf=0;var max=track.scrollWidth-track.clientWidth;
      prev.disabled=track.scrollLeft<=2;next.disabled=track.scrollLeft>=max-2;
      var w=track.clientWidth/track.scrollWidth*100;
      bar.style.width=w+'%';bar.style.left=(max>0?track.scrollLeft/max*(100-w):0)+'%';
    }
    function go(dir){var n=Math.max(1,Math.floor(track.clientWidth/step()));track.scrollBy({left:dir*n*step(),behavior:'smooth'})}
    prev.addEventListener('click',function(){go(-1)});
    next.addEventListener('click',function(){go(1)});
    track.addEventListener('scroll',function(){if(!raf)raf=requestAnimationFrame(update)},{passive:true});
    window.addEventListener('resize',update);
    track.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){e.preventDefault();go(1)}else if(e.key==='ArrowLeft'){e.preventDefault();go(-1)}});
    /* mouse drag (touch uses native swipe) */
    track.addEventListener('pointerdown',function(e){
      if(e.pointerType!=='mouse'||e.button!==0)return;
      down=true;drag=false;moved=false;sx=e.clientX;sl=track.scrollLeft;dx=0;
    });
    track.addEventListener('pointermove',function(e){
      if(!down)return;dx=e.clientX-sx;
      if(!drag&&Math.abs(dx)>5){drag=true;moved=true;track.classList.add('is-drag');try{track.setPointerCapture(e.pointerId)}catch(_){}}
      if(drag)track.scrollLeft=sl-dx;
    });
    function end(){
      if(!down)return;down=false;
      if(drag){
        drag=false;track.classList.remove('is-drag');
        var pos=track.scrollLeft/step(),idx=Math.round(pos+(dx<0?.3:-.3)*(Math.abs(dx)>40?1:0));
        track.scrollTo({left:Math.max(0,idx*step()),behavior:'smooth'});
        setTimeout(function(){moved=false},0);
      }
    }
    track.addEventListener('pointerup',end);
    track.addEventListener('pointercancel',end);
    track.addEventListener('pointerleave',end);
    track.addEventListener('click',function(e){if(moved){e.preventDefault();e.stopPropagation()}},true);
    track.addEventListener('dragstart',function(e){e.preventDefault()});
    update();
  });
})();