  // Mobile nav toggle
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');
  const mobileBar = document.querySelector('.mobile-bar');

  function syncMobileBar(){
    if(window.innerWidth <= 640){
      mobileBar.style.display = 'flex';
    } else {
      mobileBar.style.display = 'none';
      mainNav.classList.remove('open');
      navToggle.setAttribute('aria-expanded','false');
    }
  }
  window.addEventListener('resize', syncMobileBar);
  syncMobileBar();

  navToggle.addEventListener('click', () => {
    const isOpen = mainNav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', isOpen);
    navToggle.textContent = isOpen ? '✕' : '☰';
  });

  // Search product function
  const products = {
    cricket: ["Cricket Bat", "Cricket Ball", "Batting Gloves", "Cricket Kit Bag", "Leg Guards", "Helmet"],
    football: ["Football", "Shin Guards", "Football Boots", "Goal Post Net", "Training Cones"],
    badminton: ["Badminton Racket", "Shuttlecocks", "Badminton Net", "Kit Bag"],
    tennis: ["Tennis Racket", "Tennis Balls", "Grip Tape", "Tennis Kit Bag"],
    basketball: ["Basketball", "Basketball Hoop", "Jersey", "Basketball Shoes"],
    carrom: ["Carrom Board", "Carrom Coins", "Chess Board", "Chess Pieces", "Carrom Powder"],
    accessories: ["Sports Shoes", "Water Bottle", "Sports Bag", "Whistle", "Stopwatch", "Track Suit"]
  };

  const searchInput = document.getElementById('searchInput');
  const searchCategory = document.getElementById('searchCategory');
  const suggestionsBox = document.getElementById('searchSuggestions');
  const searchBtn = document.getElementById('searchBtn');

  function getFilteredProducts(query, category){
    let pool = [];
    if(category === 'all'){
      Object.values(products).forEach(list => pool.push(...list));
    } else {
      pool = products[category] || [];
    }
    if(!query){
      return pool.slice(0,8).map(p => ({name:p, cat:findCategory(p)}));
    }
    return pool
      .filter(p => p.toLowerCase().includes(query.toLowerCase()))
      .map(p => ({name:p, cat:findCategory(p)}));
  }

  function findCategory(productName){
    for(const [cat, list] of Object.entries(products)){
      if(list.includes(productName)) return cat;
    }
    return '';
  }

  function renderSuggestions(){
    const query = searchInput.value.trim();
    const category = searchCategory.value;
    const results = getFilteredProducts(query, category);

    if(results.length === 0){
      suggestionsBox.innerHTML = '<a href="#" style="color:#999;">No products found</a>';
    } else {
      suggestionsBox.innerHTML = results.map(r =>
        `<a href="/search?q=${encodeURIComponent(r.name)}&cat=${r.cat}">${r.name} <span style="color:#aaa;font-size:11px;">(${r.cat})</span></a>`
      ).join('');
    }
    suggestionsBox.classList.add('active');
  }

  searchInput.addEventListener('input', renderSuggestions);
  searchInput.addEventListener('focus', renderSuggestions);
  searchCategory.addEventListener('change', renderSuggestions);

  document.addEventListener('click', (e) => {
    if(!e.target.closest('.search-wrap')){
      suggestionsBox.classList.remove('active');
    }
  });

  function doSearch(){
    const query = searchInput.value.trim();
    const category = searchCategory.value;
    window.location.href = `/search?q=${encodeURIComponent(query)}&cat=${category}`;
  }
  searchBtn.addEventListener('click', doSearch);
  searchInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') doSearch(); });

  
  const hamburger = document.getElementById('hamburger');
  const navlist = document.getElementById('navlist');
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navlist.classList.toggle('open');
  });