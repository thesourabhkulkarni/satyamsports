/* ==========================================================================
   Sports Carousel Component — script
   Auto-initializes every element with class "sports-carousel-section"
   found on the page. Safe to include on a page that already has its own
   scripts — everything here is scoped inside one IIFE and one function,
   nothing is attached to the global namespace except SportsCarousel.init().
   ========================================================================== */
(function(){

  // Edit this list (or override per-section via a data-items attribute set
  // to a JSON string) to change the cards. Image paths are relative to
  // wherever this component's assets/ folder lives next to your page.
  const DEFAULT_CARDS = [
    {"title":"Cricket","tag":"GEAR UP. PLAY HARD. WIN BIG.","emoji":"🏏","img":"assets/cricket.jpg","href":"cricket.html",
      "footer":[{"icon":"🏏","label":"Bats"},{"icon":"🧤","label":"Gloves"},{"icon":"🦵","label":"Pads"},{"icon":"⛑️","label":"Helmets"},{"icon":"🔴","label":"Balls"}]},
    {"title":"Football","tag":"PASSION. POWER. PERFORMANCE.","emoji":"⚽","img":"assets/football.jpg","href":"football.html",
      "footer":[{"icon":"⚽","label":"Footballs"},{"icon":"👟","label":"Shoes"},{"icon":"🛡️","label":"Shin Guards"},{"icon":"🧦","label":"Socks"},{"icon":"🎒","label":"Accessories"}]},
    {"title":"Badminton","tag":"SPEED. SKILL. SMASH IT.","emoji":"🏸","img":"assets/badminton.jpg","href":"badminton.html",
      "footer":[{"icon":"🏸","label":"Rackets"},{"icon":"🌼","label":"Shuttlecocks"},{"icon":"👜","label":"Bags"},{"icon":"👟","label":"Shoes"},{"icon":"🎗️","label":"Grips"}]},
    {"title":"Tennis","tag":"FOCUS. FITNESS. FOREVER.","emoji":"🎾","img":"assets/tennis.jpg","href":"tennis.html",
      "footer":[{"icon":"🎾","label":"Rackets"},{"icon":"🟢","label":"Tennis Balls"},{"icon":"🎒","label":"Bags"},{"icon":"👟","label":"Shoes"},{"icon":"🧢","label":"Accessories"}]},
    {"title":"Basketball","tag":"DRIBBLE. SHOOT. WIN.","emoji":"🏀","img":"assets/basketball.jpg","href":"basketball.html",
      "footer":[{"icon":"🏀","label":"Basketballs"},{"icon":"👟","label":"Shoes"},{"icon":"👕","label":"Jerseys"},{"icon":"🍼","label":"Accessories"}]},
    {"title":"Carrom & Chess","tag":"FOCUS. STRATEGIZE. SUCCEED.","emoji":"♟️","img":"assets/carrom.jpg","href":"carrom.html",
      "footer":[{"icon":"▦","label":"Carrom Boards"},{"icon":"⚪","label":"Carrom Coins"},{"icon":"♞","label":"Chess Sets"},{"icon":"⏱️","label":"Chess Clocks"}]},
    {"title":"Men's Shoes","tag":"STYLE. COMFORT. PERFORMANCE.","emoji":"👟","img":"assets/shoes.jpg","href":"sportshoes.html",
      "footer":[{"icon":"👟","label":"Sneakers"},{"icon":"🥾","label":"Studs"},{"icon":"👞","label":"Casual"},{"icon":"🏃","label":"Sports"}]},
    {"title":"Sports Accessories","tag":"GEAR UP. STAY AHEAD.","emoji":"🎒","img":"assets/accessories.jpg","href":"sports_accessories.html",
      "footer":[{"icon":"🎒","label":"Bags"},{"icon":"🍶","label":"Bottles"},{"icon":"🧢","label":"Caps"},{"icon":"💪","label":"Fitness"},{"icon":"🧰","label":"Other Gear"}]}
  ];

  function cardHTML(item){
    const footerItems = item.footer.map(f => `<span><span class="sc-emoji">${f.icon}</span>${f.label}</span>`).join('');
    return `
      <a class="sc-card" href="${item.href}" draggable="false">
        <img src="${item.img}" alt="${item.title}" draggable="false">
        <div class="sc-card-overlay">
          <div class="sc-card-icon">${item.emoji}</div>
          <div class="sc-card-title">${item.title}</div>
          <div class="sc-card-tag">${item.tag}</div>
        </div>
        <div class="sc-card-footer">${footerItems}</div>
      </a>
    `;
  }

  function initSection(section){
    if(section.dataset.scInit === '1') return; // avoid double-init
    section.dataset.scInit = '1';

    let cards = DEFAULT_CARDS;
    if(section.dataset.items){
      try{ cards = JSON.parse(section.dataset.items); }catch(e){ /* fall back to defaults */ }
    }

    const track = section.querySelector('.sc-track');
    const viewport = section.querySelector('.sc-viewport');
    const dotsWrap = section.querySelector('.sc-dots');
    const prevBtn = section.querySelector('.sc-prev');
    const nextBtn = section.querySelector('.sc-next');
    if(!track || !viewport) return;

    const N = cards.length;
    const CLONE_COUNT = Math.min(3, N);
    const renderData = [
      ...cards.slice(N - CLONE_COUNT),
      ...cards,
      ...cards.slice(0, CLONE_COUNT)
    ];

    track.innerHTML = renderData.map(cardHTML).join('');

    if(dotsWrap){
      dotsWrap.innerHTML = '';
      for(let i=0;i<N;i++){
        const d = document.createElement('div');
        d.className = 'sc-dot' + (i===0 ? ' sc-active' : '');
        d.dataset.index = i;
        dotsWrap.appendChild(d);
      }
    }
    const dotEls = dotsWrap ? Array.from(dotsWrap.children) : [];

    let cardWidth = 0;
    let index = CLONE_COUNT;
    let currentX = 0;
    let isDragging = false;
    let dragStartX = 0;
    let dragBaseX = 0;
    let autoTimer = null;
    let suppressClick = false;

    function measure(){
      const cardEl = track.children[0];
      if(!cardEl) return;
      const style = getComputedStyle(cardEl);
      cardWidth = cardEl.getBoundingClientRect().width + parseFloat(style.marginRight);
    }

    function setTransition(on){
      track.style.transition = on ? 'transform .45s cubic-bezier(.22,.9,.32,1)' : 'none';
    }

    function goTo(i, animate){
      index = i;
      setTransition(animate);
      currentX = -index * cardWidth;
      track.style.transform = `translate3d(${currentX}px,0,0)`;
      updateDots();
    }

    function updateDots(){
      if(!dotEls.length) return;
      let real = (index - CLONE_COUNT) % N;
      if(real < 0) real += N;
      dotEls.forEach((d, i) => d.classList.toggle('sc-active', i === real));
    }

    function next(){ goTo(index + 1, true); }
    function prev(){ goTo(index - 1, true); }

    track.addEventListener('transitionend', () => {
      if(index >= N + CLONE_COUNT){ goTo(index - N, false); }
      else if(index < CLONE_COUNT){ goTo(index + N, false); }
    });

    function resetAuto(){
      clearInterval(autoTimer);
      autoTimer = setInterval(next, 4500);
    }

    if(prevBtn) prevBtn.addEventListener('click', () => { resetAuto(); prev(); });
    if(nextBtn) nextBtn.addEventListener('click', () => { resetAuto(); next(); });

    dotEls.forEach(d => {
      d.addEventListener('click', () => {
        resetAuto();
        goTo(CLONE_COUNT + parseInt(d.dataset.index, 10), true);
      });
    });

    function pointerDown(clientX){
      isDragging = true;
      setTransition(false);
      dragStartX = clientX;
      dragBaseX = currentX;
      viewport.classList.add('sc-dragging');
      resetAuto();
    }
    function pointerMove(clientX){
      if(!isDragging) return;
      const dx = clientX - dragStartX;
      currentX = dragBaseX + dx;
      track.style.transform = `translate3d(${currentX}px,0,0)`;
      if(Math.abs(dx) > 6) suppressClick = true;
    }
    function pointerUp(clientX){
      if(!isDragging) return;
      isDragging = false;
      viewport.classList.remove('sc-dragging');
      const dx = clientX - dragStartX;
      const threshold = cardWidth * 0.18;
      if(dx <= -threshold){ goTo(index + 1, true); }
      else if(dx >= threshold){ goTo(index - 1, true); }
      else { goTo(index, true); }
    }

    viewport.addEventListener('mousedown', (e) => { e.preventDefault(); suppressClick = false; pointerDown(e.clientX); });
    window.addEventListener('mousemove', (e) => pointerMove(e.clientX));
    window.addEventListener('mouseup', (e) => pointerUp(e.clientX));
    viewport.addEventListener('mouseleave', (e) => { if(isDragging) pointerUp(e.clientX); });

    viewport.addEventListener('touchstart', (e) => { pointerDown(e.touches[0].clientX); }, {passive:true});
    viewport.addEventListener('touchmove', (e) => { pointerMove(e.touches[0].clientX); }, {passive:true});
    viewport.addEventListener('touchend', (e) => { pointerUp(e.changedTouches[0].clientX); });

    track.addEventListener('click', (e) => {
      if(suppressClick){ e.preventDefault(); suppressClick = false; }
    }, true);

    window.addEventListener('resize', () => { measure(); goTo(index, false); });

    measure();
    goTo(CLONE_COUNT, false);
    resetAuto();
  }

  function initAll(){
    document.querySelectorAll('.sports-carousel-section').forEach(initSection);
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  // Expose a manual init in case the section is injected into the page later
  window.SportsCarousel = { init: initAll };

})();
