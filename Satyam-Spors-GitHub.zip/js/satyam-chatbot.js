/* Satyam Sports – AI Chat Assistant (bubble widget). Add before </body>:
   <script src="js/satyam-chatbot.js" defer></script> */
(function () {
  var CFG = {
    shop: 'Satyam Sports', email: 'info.satyamsports@gmail.com', phone: '9423325141', wa: '919423325141',
    address: 'Shop No. 17, Park Chowk, Solapur 413001',
    hours: 'Mon – Sat, 10:00 AM – 9:00 PM',
    map: 'https://www.google.com/maps/search/?api=1&query=Satyam+Sports+Park+Chowk+Solapur+413001'
  };
  var ENDPOINT = 'https://formsubmit.co/ajax/' + CFG.email;

  var CAT = {
    'Cricket': ['GM Leather Cricket Bat','SF Leather Cricket Bat','Kookaburra English Willow Bat','Velox & Khanna Cricket Bats','Khanna Super Cricket Bat','Riaka Turbo Cricket Bats','Riaka Sports Series Bats','SG Duffle Eco-Combo Kit','Khanna Academy Cricket Kit','Khanna Complete Cricket Kit','Leather Cricket Balls','Club Leather Cricket Balls','Bowling Machine – 12-Ball Auto Feeder'],
    'Football': ['Nike Mercurial Football Boots','Nivia Airstrike Studs','Nivia Dominator 3.0 Football','Puma LaLiga Adrenalina Match Ball','Vector X Attacker 2.0 Football','Khanna Super Football','Gripmode Keeper Gloves','Nivia Double Action Ball Pump'],
    'Badminton': ['Kimony 3-in-1 Shuttlecocks','Hangdrer Badminton Racket Combo','Yonex Badminton Backpack','Yonex Complete Badminton Kit','Yonex Pro Badminton Kit','Vixen Rapid Fire Shuttlecock','Vixen VX-3 Badminton Racket'],
    'Tennis': ['Babolat Tennis Rackets','Babolat Complete Tennis Kit','Head Titanium Tennis Racket','Vinex Smash Tennis Racket','Yonex Tennis Racket','Wilson Pink Tennis Kit','Yonex Tour Tennis Balls','Insum Bulk Tennis Balls (30)','Adidas Tennis Shoes'],
    'Basketball': ['Nike Elite All-Court Basketball','Puma Basketball','Nike Mini Basketball','Silent Foam Basketball & Hoop Set','Elite Basketball Jersey & Shorts Set','Nike Basketball Shoes'],
    'Carrom & Chess': ['Carrom Board Set with Coins & Powder','Carrom Coins with Striker & Powder','Proverve Carrom Coin Set','Wooden Chess Set with Storage Box','Tournament Chess Set with Carry Case','Weighted Chess Pieces','Roll-Up Chess Board Mat'],
    'Shoes & Sneakers': ['Adidas High-Top Shoes','Sport Fashion Sneakers','White Air-Cushion Sneakers','Abros Chance Running Shoes','Abros Phoenix Running Shoes','Nivia Running Shoes','Nike Zoom Shoes','Under Armour Basketball Shoes','Encounter Football Studs','Nivia Football Studs','Sega Football Studs (Metallic / Classic / Spectra Plus)','DSC Belter Cricket Shoes','DSC Fearless Cricket Shoes','SG Greenlands Cricket Shoes'],
    'Sports Accessories': ['Cricket Bat Grips with Grip Cone','Nextage Abdominal Guard','Pro-Toner Cricket Stumps with Base','Korbax Hanging Practice Ball','Lycan Wind Balls (3)','Bullfitz Wind Balls (3)','Coloured Cricket Balls','Khanna Tango Heavy Tennis Balls','Stag Active 16 Table Tennis Table','Nivia Grip Football Socks','Nivia Knee Support','Nivia Skipping Rope','Cotton Skipping Rope','Resistance Bands Set','Konex Yoga Mat','Colourful Wooden Cone']
  };
  var CATKEY = { 'Cricket':'cricket bat ball kit stumps pads', 'Football':'football soccer studs boots gloves goalkeeper', 'Badminton':'badminton shuttle shuttlecock', 'Tennis':'tennis racket racquet', 'Basketball':'basketball hoop jersey', 'Carrom & Chess':'carrom chess board coins', 'Shoes & Sneakers':'shoes sneakers running studs footwear', 'Sports Accessories':'accessories grip guard skipping yoga rope band table tennis socks knee' };

  var lead = { name:'', phone:'', email:'' }, log = [], step = null, userMsgs = 0, asked = false, sendTimer = null, sentOnce = false;

  var css = '#ssb-btn{position:fixed;right:18px;bottom:18px;z-index:99999;width:62px;height:62px;border-radius:50%;border:0;cursor:pointer;background:linear-gradient(135deg,#ff7a1a,#e8460b);color:#fff;font-size:28px;box-shadow:0 6px 20px rgba(0,0,0,.3);transition:transform .2s}#ssb-btn:hover{transform:scale(1.08)}#ssb-btn .dot{position:absolute;top:4px;right:4px;width:14px;height:14px;background:#22c55e;border:2px solid #fff;border-radius:50%}' +
  '#ssb-box{position:fixed;right:18px;bottom:92px;z-index:99999;width:370px;max-width:calc(100vw - 24px);height:560px;max-height:calc(100vh - 110px);background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.28);display:none;flex-direction:column;overflow:hidden;font-family:Poppins,Segoe UI,Arial,sans-serif;font-size:14px}#ssb-box.open{display:flex;animation:ssbIn .25s ease}@keyframes ssbIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}' +
  '.ssb-h{background:linear-gradient(135deg,#0f1f3d,#1d3a6e);color:#fff;padding:12px 14px;display:flex;align-items:center;gap:10px}.ssb-av{width:38px;height:38px;border-radius:50%;background:#ff7a1a;display:flex;align-items:center;justify-content:center;font-size:20px}.ssb-h b{display:block;font-size:15px}.ssb-h small{opacity:.8;font-size:11px}.ssb-x{margin-left:auto;background:none;border:0;color:#fff;font-size:22px;cursor:pointer}' +
  '.ssb-m{flex:1;overflow-y:auto;padding:12px;background:#f4f6fa;display:flex;flex-direction:column;gap:8px}.ssb-b{max-width:86%;padding:9px 12px;border-radius:14px;line-height:1.45;word-wrap:break-word}.ssb-b a{color:#e8460b;font-weight:600}.ssb-bot{background:#fff;color:#1b2333;align-self:flex-start;border-bottom-left-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.08)}.ssb-usr{background:#e8460b;color:#fff;align-self:flex-end;border-bottom-right-radius:4px}' +
  '.ssb-q{display:flex;flex-wrap:wrap;gap:6px;align-self:flex-start}.ssb-q button{background:#fff;border:1px solid #e8460b;color:#e8460b;border-radius:16px;padding:5px 11px;font-size:12.5px;cursor:pointer;font-family:inherit}.ssb-q button:hover{background:#e8460b;color:#fff}.ssb-ty{align-self:flex-start;color:#888;font-size:12px;padding-left:4px}' +
  '.ssb-f{display:flex;gap:6px;padding:10px;border-top:1px solid #e6e9ef;background:#fff}.ssb-f input{flex:1;border:1px solid #d5dae3;border-radius:20px;padding:9px 13px;font-size:14px;outline:none;font-family:inherit;min-width:0}.ssb-f input:focus{border-color:#e8460b}.ssb-f button{background:#e8460b;color:#fff;border:0;border-radius:50%;width:40px;height:40px;cursor:pointer;font-size:17px}' +
  '.ssb-ft{text-align:center;font-size:10.5px;color:#8a93a5;padding:0 0 6px;background:#fff}@supports(height:1dvh){#ssb-box{max-height:calc(100dvh - 110px)}}#ssb-tip{position:fixed;right:90px;bottom:30px;z-index:99998;background:#fff;color:#1b2333;padding:9px 13px;border-radius:14px;box-shadow:0 4px 16px rgba(0,0,0,.22);font:13px/1.4 Poppins,Segoe UI,Arial,sans-serif;cursor:pointer;display:none;max-width:190px}#ssb-tip b{color:#e8460b}#ssb-box.inline{position:relative;right:auto;left:auto;bottom:auto;width:100%;max-width:680px;height:520px;max-height:none;margin:0 auto;box-shadow:0 4px 18px rgba(0,0,0,.15);border:1px solid #e6e9ef;animation:none}#ssb-box.inline .ssb-x{display:none}@media(max-width:480px){#ssb-box{left:8px;right:8px;width:auto;max-width:none;bottom:calc(84px + env(safe-area-inset-bottom,0px));height:calc(100vh - 110px)}@supports(height:1dvh){#ssb-box{height:calc(100dvh - 110px)}}#ssb-btn{right:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px))}#ssb-tip{right:84px;bottom:26px}#ssb-box.inline{left:auto;right:auto;width:100%;height:480px;bottom:auto}.ssb-f input{font-size:16px}}';

  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  var root = document.createElement('div');
  root.innerHTML = '<button id="ssb-btn" style="display:' + (host ? 'none' : 'block') + '" aria-label="Chat with Satyam Sports">💬<span class="dot"></span></button>' +
    '<div id="ssb-box" role="dialog" aria-label="Satyam Sports chat"><div class="ssb-h"><div class="ssb-av">🏏</div><div><b>Satyam Sports Virtual Assistant</b><small>● Online 24/7 · Replies instantly</small></div><button class="ssb-x" aria-label="Close">×</button></div>' +
    '<div class="ssb-m" id="ssb-m"></div><form class="ssb-f" id="ssb-f"><input id="ssb-i" autocomplete="off" placeholder="Type your question…" aria-label="Message"><button aria-label="Send">➤</button></form><div class="ssb-ft">Satyam Sports · Park Chowk, Solapur</div></div>';
  var host = document.getElementById('satyam-assistant');
  (host || document.body).appendChild(root);
  var btn = root.querySelector('#ssb-btn'), box = root.querySelector('#ssb-box'), msgs = root.querySelector('#ssb-m'), inp = root.querySelector('#ssb-i');

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function scroll() { msgs.scrollTop = msgs.scrollHeight; }
  function add(html, cls, plain) { var d = document.createElement('div'); d.className = 'ssb-b ' + cls; d.innerHTML = html; msgs.appendChild(d); scroll(); log.push((cls === 'ssb-usr' ? 'Customer: ' : 'Bot: ') + (plain || d.textContent)); return d; }
  function chips(list) { var d = document.createElement('div'); d.className = 'ssb-q'; list.forEach(function (t) { var b = document.createElement('button'); b.type = 'button'; b.textContent = t; b.onclick = function () { d.remove(); handle(t); }; d.appendChild(b); }); msgs.appendChild(d); scroll(); }
  function bot(html, ch) { var t = document.createElement('div'); t.className = 'ssb-ty'; t.textContent = 'typing…'; msgs.appendChild(t); scroll(); setTimeout(function () { t.remove(); add(html, 'ssb-bot'); if (ch) chips(ch); }, 450); }

  var MAIN = ['Products','Prices','Timings','Address','Contact','Leave my number'];
  var wa = function (t) { return 'https://wa.me/' + CFG.wa + '?text=' + encodeURIComponent(t || 'Hi Satyam Sports, I have an enquiry'); };
  var waLink = '<a href="' + wa() + '" target="_blank" rel="noopener">WhatsApp</a>';

  function openNow() {
    var n = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })), d = n.getDay(), h = n.getHours() + n.getMinutes() / 60;
    return d !== 0 && h >= 10 && h < 21;
  }
  function hoursMsg() { return '🕙 <b>Store hours:</b> ' + CFG.hours + '<br>Closed on Sundays.<br>🤖 I am available <b>24/7</b> for your questions.<br>' + (openNow() ? '✅ We are <b>open right now</b>.' : '⏰ We are <b>closed right now</b> – leave your number and we will call you back when we open.'); }
  function addrMsg() { return '📍 <b>' + CFG.shop + '</b><br>' + CFG.address + '<br><a href="' + CFG.map + '" target="_blank" rel="noopener">Open in Google Maps</a>'; }
  function contactMsg() { return '📞 Call: <a href="tel:+91' + CFG.phone + '">' + CFG.phone + '</a><br>💬 ' + waLink + ': +91 ' + CFG.phone + '<br>✉️ <a href="mailto:' + CFG.email + '">' + CFG.email + '</a>'; }
  function priceMsg() { return '💰 Prices depend on brand, model, size and current stock, so we quote them personally – you get the best rate this way.<br><br>Tell me the product you want and share your number, or ask on ' + waLink + ' for a quick quote.'; }
  function catList() { return Object.keys(CAT); }
  function showCat(c) { return '<b>' + c + '</b> at Satyam Sports:<br>• ' + CAT[c].map(esc).join('<br>• ') + '<br><br>Want a price for any of these?'; }

  function findProducts(q) {
    var toks = q.split(/[^a-z0-9]+/).filter(function (t) { return t.length > 2 && !/the|and|for|you|have|any|price|cost|rate|how|much|what|which|show|want|need|buy|available|stock|with|your|got/.test(t); });
    if (!toks.length) return [];
    var out = [];
    Object.keys(CAT).forEach(function (c) { CAT[c].forEach(function (p) { var l = p.toLowerCase(), s = 0; toks.forEach(function (t) { if (l.indexOf(t) > -1) s++; }); if (s) out.push({ p: p, c: c, s: s }); }); });
    out.sort(function (a, b) { return b.s - a.s; });
    return out.slice(0, 6);
  }

  function reply(q) {
    var l = q.toLowerCase();
    if (/^(hi|hello|hey|namaste|hii+|good (morning|afternoon|evening))\b/.test(l)) return ['👋 Hello! Welcome to <b>Satyam Sports</b>, Solapur. How can I help you today?', MAIN];
    if (/price|cost|rate|how much|kitna|kimat|budget|cheap|discount|offer|emi/.test(l)) { var f = findProducts(l); return [priceMsg() + (f.length ? '<br><br>You asked about: <b>' + esc(f[0].p) + '</b>.' : ''), ['Leave my number','WhatsApp quote']]; }
    if (/24\/7|24 hours|24x7|always open|anytime|support/.test(l)) return ['🤖 Yes! I am your virtual assistant and I answer 24/7 – day or night. Our shop team is available ' + CFG.hours + '. Leave your number and we will call you back.', ['Leave my number','Timings']];
    if (/time|timing|hour|open|close|when|sunday|holiday/.test(l)) return [hoursMsg(), ['Address','Leave my number']];
    if (/address|where|location|locate|direction|map|park chowk|visit|reach|shop no/.test(l)) return [addrMsg(), ['Timings','Contact']];
    if (/contact|phone|call|number|mobile|email|mail|whatsapp|talk|human|owner|speak/.test(l) && !/leave|my number/.test(l)) return [contactMsg(), ['Leave my number','Products']];
    if (/deliver|shipping|courier|home delivery|return|exchange|warranty|guarantee|gst|bill|invoice|bulk|school|club|academy|team order/.test(l)) return ['For delivery, exchange/warranty, bulk or school/club orders, our team confirms the details personally. Share your number and we will call you, or message us on ' + waLink + '.', ['Leave my number','Contact']];
    if (/order|buy|purchase|book|reserve/.test(l)) return ['🛒 Easy! Order on ' + waLink + ' or visit the store. Share your number and we will confirm availability & price.', ['Leave my number','Products']];
    if (/thank|thanks|ok thanks|great|awesome/.test(l)) return ['You are welcome! 😊 Anything else I can help with?', MAIN];
    if (/bye|goodbye|see you/.test(l)) return ['Thanks for chatting with Satyam Sports! Visit us at Park Chowk, Solapur. 🏏', null];
    if (/(all|what).*(product|categor|sport|sell|item)|^products?$|catalog|range|what do you (have|sell)/.test(l)) return ['We stock gear for these sports – tap one to see products:', catList()];
    for (var c in CAT) { if (l.indexOf(c.toLowerCase().split(' ')[0]) > -1 || CATKEY[c].split(' ').some(function (k) { return k.length > 3 && l.indexOf(k) > -1; })) { var m = findProducts(l); if (m.length && m.length < 6 && m[0].s > 0 && l.split(' ').length > 1) break; return [showCat(c), ['Prices','Leave my number']]; } }
    var found = findProducts(l);
    if (found.length) return ['Yes, we have these:<br>• ' + found.map(function (x) { return '<b>' + esc(x.p) + '</b> <small>(' + x.c + ')</small>'; }).join('<br>• ') + '<br><br>Prices & stock on request – shall I take your number?', ['Leave my number','Products']];
    return ['I could not find that exactly, but our team can help. You can call <a href="tel:+91' + CFG.phone + '">' + CFG.phone + '</a>, message on ' + waLink + ', or leave your number and we will get back to you.', ['Leave my number','Products','Contact']];
  }

  /* ---- lead capture ---- */
  function startLead() { step = 'name'; bot('Happy to help! 😊 May I have your <b>name</b>?'); }
  function ask(t) { bot(t); }
  function leadStep(v) {
    if (step === 'name') { if (v.length < 2) return ask('Please enter your name.'); lead.name = v.slice(0, 60); step = 'phone'; return ask('Thanks, <b>' + esc(lead.name) + '</b>! Your <b>mobile number</b>? (10 digits)'); }
    if (step === 'phone') { var p = v.replace(/[\s\-+()]/g, '').replace(/^(91|0)(?=\d{10}$)/, ''); if (!/^[6-9]\d{9}$/.test(p)) return ask('That number does not look right. Please enter a valid 10-digit mobile number.'); lead.phone = p; step = 'email'; return ask('Great! And your <b>email address</b>?'); }
    if (step === 'email') { if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return ask('Please enter a valid email, e.g. name@gmail.com'); lead.email = v; step = null; send('New customer lead'); return bot('✅ Thank you, ' + esc(lead.name) + '! Your details are with our team and we will contact you shortly.<br>Meanwhile, ask me anything about products, timings or the store.', MAIN); }
  }

  function send(subject) {
    if (!lead.phone) return;
    var body = { _subject: '[Satyam Sports Chatbot] ' + subject + ' – ' + lead.name, _captcha: 'false', _template: 'table',
      Name: lead.name, Phone: lead.phone, Email: lead.email, Page: location.href,
      Time: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }), Conversation: log.slice(-40).join('\n') };
    try { fetch(ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body), keepalive: true }).then(function (r) { sentOnce = true; }).catch(function () {}); } catch (e) {}
  }
  function queueUpdate() { if (!lead.phone) return; clearTimeout(sendTimer); sendTimer = setTimeout(function () { send('Chat update'); }, 45000); }
  window.addEventListener('pagehide', function () { if (lead.phone && sendTimer) { clearTimeout(sendTimer); send('Chat update'); } });

  function handle(text) {
    text = text.trim(); if (!text) return;
    add(esc(text), 'ssb-usr', text);
    if (step) return leadStep(text);
    userMsgs++;
    var l = text.toLowerCase();
    if (/leave my number|call me|callback|call back|contact me|whatsapp quote/.test(l)) { if (/whatsapp quote/.test(l)) return bot('Tap to get a quick quote on ' + waLink + ' 👈', MAIN); if (lead.phone) return bot('We already have your details (' + esc(lead.phone) + '). Our team will contact you soon!', MAIN); return startLead(); }
    if (/^not now$/.test(l)) return bot('No problem! Ask me anything else anytime. 🙂', MAIN);
    var r = reply(l); bot(r[0], r[1]); queueUpdate();
    if (!lead.phone && !asked && userMsgs >= 3) { asked = true; setTimeout(function () { bot('By the way, want us to call you with exact prices & availability? Share your number 👇', ['Leave my number','Not now']); }, 1400); }
  }

  var greeted = false;
  function toggle(open) {
    box.classList.toggle('open', open);
    if (open) { btn.querySelector('.dot').style.display = 'none'; if (!greeted) { greeted = true; bot('👋 Hi! I\'m the <b>Satyam Sports</b> assistant. Ask me about <b>products, prices, timings, address</b> or contact details. I am here <b>24/7</b>.' + (openNow() ? '' : '<br><small>🌙 The shop is closed now – leave your number and we will call you when we open.</small>'), MAIN); } if (!host) setTimeout(function () { inp.focus(); }, 300); var tp = document.getElementById('ssb-tip'); if (tp) tp.style.display = 'none'; }
  }
  btn.onclick = function () { toggle(!box.classList.contains('open')); };
  root.querySelector('.ssb-x').onclick = function () { toggle(false); };
  root.querySelector('#ssb-f').onsubmit = function (e) { e.preventDefault(); var v = inp.value; inp.value = ''; handle(v); };
  if (host) { box.classList.add('inline'); toggle(true); }
  else {
    var tip = document.createElement('div'); tip.id = 'ssb-tip'; tip.innerHTML = '👋 Need help? <b>Ask me – 24/7</b>'; document.body.appendChild(tip);
    tip.onclick = function () { toggle(true); };
    setTimeout(function () { if (!greeted) tip.style.display = 'block'; }, 5000);
    setTimeout(function () { tip.style.display = 'none'; }, 20000);
  }
})();