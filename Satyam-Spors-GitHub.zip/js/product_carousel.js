(function(){
  const CARD_DATA = [
    {"title":"Cricket","tag":"GEAR UP. PLAY HARD. WIN BIG.","emoji":"🏏","img":"assets/cricket.jpg","href":"#cricket",
      "footer":[{"icon":"🏏","label":"Bats"},{"icon":"🧤","label":"Gloves"},{"icon":"🦵","label":"Pads"},{"icon":"⛑️","label":"Helmets"},{"icon":"🔴","label":"Balls"}]},
    {"title":"Football","tag":"PASSION. POWER. PERFORMANCE.","emoji":"⚽","img":"assets/football.jpg","href":"#football",
      "footer":[{"icon":"⚽","label":"Footballs"},{"icon":"👟","label":"Shoes"},{"icon":"🛡️","label":"Shin Guards"},{"icon":"🧦","label":"Socks"},{"icon":"🎒","label":"Accessories"}]},
    {"title":"Badminton","tag":"SPEED. SKILL. SMASH IT.","emoji":"🏸","img":"assets/badminton.jpg","href":"#badminton",
      "footer":[{"icon":"🏸","label":"Rackets"},{"icon":"🌼","label":"Shuttlecocks"},{"icon":"👜","label":"Bags"},{"icon":"👟","label":"Shoes"},{"icon":"🎗️","label":"Grips"}]},
    {"title":"Tennis","tag":"FOCUS. FITNESS. FOREVER.","emoji":"🎾","img":"assets/tennis.jpg","href":"#tennis",
      "footer":[{"icon":"🎾","label":"Rackets"},{"icon":"🟢","label":"Tennis Balls"},{"icon":"🎒","label":"Bags"},{"icon":"👟","label":"Shoes"},{"icon":"🧢","label":"Accessories"}]},
    {"title":"Basketball","tag":"DRIBBLE. SHOOT. WIN.","emoji":"🏀","img":"assets/basketball.jpg","href":"#basketball",
      "footer":[{"icon":"🏀","label":"Basketballs"},{"icon":"👟","label":"Shoes"},{"icon":"👕","label":"Jerseys"},{"icon":"🍼","label":"Accessories"}]},
    {"title":"Carrom & Chess","tag":"FOCUS. STRATEGIZE. SUCCEED.","emoji":"♟️","img":"assets/carrom.jpg","href":"#carrom-chess",
      "footer":[{"icon":"▦","label":"Carrom Boards"},{"icon":"⚪","label":"Carrom Coins"},{"icon":"♞","label":"Chess Sets"},{"icon":"⏱️","label":"Chess Clocks"}]},
    {"title":"Men's Shoes","tag":"STYLE. COMFORT. PERFORMANCE.","emoji":"👟","img":"assets/shoes.jpg","href":"#mens-shoes",
      "footer":[{"icon":"👟","label":"Sneakers"},{"icon":"🥾","label":"Studs"},{"icon":"👞","label":"Casual"},{"icon":"🏃","label":"Sports"}]},
    {"title":"Sports Accessories","tag":"GEAR UP. STAY AHEAD.","emoji":"🎒","img":"assets/accessories.jpg","href":"#accessories",
      "footer":[{"icon":"🎒","label":"Bags"},{"icon":"🍶","label":"Bottles"},{"icon":"🧢","label":"Caps"},{"icon":"💪","label":"Fitness"},{"icon":"🧰","label":"Other Gear"}]}
  ];

  const track = document.getElementById('track');
  const viewport = document.getElementById('viewport');
  const dotsWrap = document.getElementById('dots');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');

  const N = CARD_DATA.length;
  const CLONE_COUNT = 3;
  const renderData = [
    ...CARD_DATA.slice(N - CLONE_COUNT),
    ...CARD_DATA,
    ...CARD_DATA.slice(0, CLONE_COUNT)
  ];

  function cardHTML(item){
    const footerItems = item.footer.map(f => `<span><span class="emoji">${f.icon}</span>${f.label}</span>`).join('');
    return `
      <a class="card" href="${item.href}" draggable="false">
        <img src="${item.img}" alt="${item.title}" draggable="false">
        <div class="card-overlay">
          <div class="card-icon">${item.emoji}</div>
          <div class="card-title">${item.title}</div>
          <div class="card-tag">${item.tag}</div>
        </div>
        <div class="card-footer">${footerItems}</div>
      </a>
    `;
  }

  track.innerHTML = renderData.map(cardHTML).join('');

  for(let i=0;i<N;i++){
    const d = document.createElement('div');
    d.className = 'dot' + (i===0 ? ' active' : '');
    d.dataset.index = i;
    dotsWrap.appendChild(d);
  }
  const dotEls = Array.from(dotsWrap.children);

  let cardWidth = 0;
  let index = CLONE_COUNT;
  let currentX = 0;
  let isDragging = false;
  let dragStartX = 0;
  let dragBaseX = 0;
  let autoTimer = null;

  function measure(){
    const cardEl = track.children[0];
    const style = getComputedStyle(cardEl);
    cardWidth = cardEl.getBoundingClientRect().width + parseFloat(style.marginRight);
  }

  function setTransition(on){
    track.style.transition = on ? 'transform .45s cubic-bezier(.22,.9,.32,1)' : 'none';
  }

  function goTo(i, animate=true){
    index = i;
    setTransition(animate);
    currentX = -index * cardWidth;
    track.style.transform = `translate3d(${currentX}px,0,0)`;
    updateDots();
  }

  function updateDots(){
    let real = (index - CLONE_COUNT) % N;
    if(real < 0) real += N;
    dotEls.forEach((d, i) => d.classList.toggle('active', i === real));
  }

  function next(){ goTo(index + 1, true); }
  function prev(){ goTo(index - 1, true); }

  track.addEventListener('transitionend', () => {
    if(index >= N + CLONE_COUNT){
      goTo(index - N, false);
    } else if(index < CLONE_COUNT){
      goTo(index + N, false);
    }
  });

  prevBtn.addEventListener('click', () => { resetAuto(); prev(); });
  nextBtn.addEventListener('click', () => { resetAuto(); next(); });

  dotEls.forEach(d => {
    d.addEventListener('click', () => {
      resetAuto();
      const target = CLONE_COUNT + parseInt(d.dataset.index, 10);
      goTo(target, true);
    });
  });

  function pointerDown(clientX){
    isDragging = true;
    setTransition(false);
    dragStartX = clientX;
    dragBaseX = currentX;
    viewport.classList.add('dragging');
    resetAuto();
  }
  function pointerMove(clientX){
    if(!isDragging) return;
    const dx = clientX - dragStartX;
    currentX = dragBaseX + dx;
    track.style.transform = `translate3d(${currentX}px,0,0)`;
  }
  function pointerUp(clientX){
    if(!isDragging) return;
    isDragging = false;
    viewport.classList.remove('dragging');
    const dx = clientX - dragStartX;
    const threshold = cardWidth * 0.18;
    if(dx <= -threshold){ goTo(index + 1, true); }
    else if(dx >= threshold){ goTo(index - 1, true); }
    else { goTo(index, true); }
  }

  viewport.addEventListener('mousedown', (e) => { e.preventDefault(); pointerDown(e.clientX); });
  window.addEventListener('mousemove', (e) => pointerMove(e.clientX));
  window.addEventListener('mouseup', (e) => pointerUp(e.clientX));
  viewport.addEventListener('mouseleave', (e) => { if(isDragging) pointerUp(e.clientX); });

  viewport.addEventListener('touchstart', (e) => { pointerDown(e.touches[0].clientX); }, {passive:true});
  viewport.addEventListener('touchmove', (e) => { pointerMove(e.touches[0].clientX); }, {passive:true});
  viewport.addEventListener('touchend', (e) => { pointerUp(e.changedTouches[0].clientX); });

  let suppressClick = false;
  window.addEventListener('mousemove', (e) => {
    if(isDragging && Math.abs(e.clientX - dragStartX) > 6) suppressClick = true;
  });
  track.querySelectorAll('a.card').forEach(a => {
    a.addEventListener('click', (e) => {
      if(suppressClick){ e.preventDefault(); suppressClick = false; }
    });
  });
  viewport.addEventListener('mousedown', () => { suppressClick = false; });

  function resetAuto(){
    clearInterval(autoTimer);
    autoTimer = setInterval(next, 4500);
  }

  window.addEventListener('resize', () => {
    measure();
    goTo(index, false);
  });

  measure();
  goTo(CLONE_COUNT, false);
  resetAuto();
})();